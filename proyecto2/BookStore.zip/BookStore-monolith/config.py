import os

SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://bookstore_user:bookstore_pass@db/bookstore'
SECRET_KEY = 'secretkey'
SQLALCHEMY_TRACK_MODIFICATIONS = False
